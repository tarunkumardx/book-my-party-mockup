import React from 'react';

const CheckoutPage = () => {
  return (
    <div>
      <button>Add to cart</button>
    </div>
  )
}

export default CheckoutPage