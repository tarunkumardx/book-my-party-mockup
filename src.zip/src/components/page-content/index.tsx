import React from 'react'

const PageContent = () => {
  return (
    <>
      pagecontet
    </>
  )
}

export default PageContent
